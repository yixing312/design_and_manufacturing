Data_path = "../data/"

with open(Data_path + "task_queue.txt", "w", encoding="utf8") as f:
    f.write("end")
